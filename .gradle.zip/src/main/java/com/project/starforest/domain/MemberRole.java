package com.project.starforest.domain;

public enum MemberRole {
	USER,ADMIN;
}
