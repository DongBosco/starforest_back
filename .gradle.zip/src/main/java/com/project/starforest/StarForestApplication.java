package com.project.starforest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarForestApplication {

    public static void main(String[] args) {
        SpringApplication.run(StarForestApplication.class, args);
    }

}
